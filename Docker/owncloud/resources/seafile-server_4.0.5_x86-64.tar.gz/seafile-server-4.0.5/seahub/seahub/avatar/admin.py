from django.contrib import admin
from seahub.avatar.models import Avatar

admin.site.register(Avatar)
