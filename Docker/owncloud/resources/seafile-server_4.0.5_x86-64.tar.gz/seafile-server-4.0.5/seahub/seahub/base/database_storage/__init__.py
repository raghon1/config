# Allow users to: from database_storage import DatabaseStorage
# (reduce redundancy a little bit)

from database_storage import *
